# ============================================================
# Phase-Field Fracture Simulation in FEniCS
# Half-Domain Symmetric Formulation
# ============================================================

# ------------------------------------------------------------
# Overview
# ------------------------------------------------------------

This project implements a staggered phase-field fracture
simulation using the finite element method in FEniCS.

The problem consists of a rectangular domain containing
a circular hole subjected to displacement-controlled loading.
The goal is to study the evolution of fracture/damage
within the material using a variational phase-field model.

To remove mesh-induced left/right asymmetry, the simulation
was reformulated on HALF of the original domain using
symmetry boundary conditions. This also reduces the computational
cost by half.


# ------------------------------------------------------------
# Physical Model
# ------------------------------------------------------------

The displacement field: u(x)

and damage field: d(x)

are solved iteratively.

The damage variable satisfies:

#   d = 0   --> undamaged
#   d = 1   --> fully fractured

The elastic stiffness is degraded using:

#   g(d) = (1-d)^2 + k_res

where k_res is a small residual stiffness parameter used to avoid
singular stiffness matrices.

The fracture formulation uses a tension-compression split 
(Amor split) so that only tensile elastic energy drives
damage evolution.

The history field H(x) stores the maximum tensile energy previously attained,
thereby enforcing irreversibility of fracture.


# ------------------------------------------------------------
# Numerical Formulation
# ------------------------------------------------------------

The problem is solved using a staggered (alternate
minimization) approach.

At each load increment:

1. Solve displacement problem
2. Update history field
3. Solve damage problem
4. Repeat until convergence

This process continues until the damage increment becomes
sufficiently small.

The displacement problem is nonlinear because the stress
depends on the damage field through the degradation function.

The damage problem is solved as a linear variational problem.


# ------------------------------------------------------------
# Symmetry Boundary Condition
# ------------------------------------------------------------

To enforce mirror symmetry across x = 0.5,
the following condition is imposed:
#   u_x = 0
on the symmetry boundary.

Importantly u_y is left unconstrained.


# ------------------------------------------------------------
# Outputs
# ------------------------------------------------------------

The simulation stores:

1. Damage field
2. Displacement field
3. Force-displacement response
4. Elastic energy
5. Fracture energy
6. PNG visualizations of damage evolution
7. XDMF files for ParaView visualization

# ------------------------------------------------------------
# Running the Simulation
# ------------------------------------------------------------

Before each simulation:

- the results directory is automatically cleared
- a new results directory is created

The code then:

1. Generates the mesh
2. Solves the staggered phase-field problem
3. Saves outputs at each load increment

# ------------------------------------------------------------
# Visualization
# ------------------------------------------------------------

The generated XDMF files can be visualized in:

- ParaView

for detailed analysis of:

- damage evolution
- stress localization
- crack propagation
- displacement fields

# ============================================================
